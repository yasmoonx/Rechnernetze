from Sender import *
from Receiver import *

client = Receiver()
server = Sender()
